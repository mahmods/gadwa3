<template>
    <div class="container page-content">
        <!-- Steps -->
        <div class="steps">
            <div class="step-item done">
                <i></i>
                <router-link v-on:click.native="createSixStep()" :to="{ name: 'Stepone' }"><span>بيانات المشروع</span>
                </router-link>
            </div>
            <div class="step-item done">
                <i></i>
                <router-link v-on:click.native="createFourthStep()" to="/step-2"><span>بيانات السوق</span></router-link>
            </div>
            <div class="step-item done">
                <i></i>
                <router-link v-on:click.native="createSixStep()" to="/step-3"><span>الطاقه الانتاجيه</span>
                </router-link>
            </div>
            <div class="step-item done">
                <i></i>
                <router-link v-on:click.native="createSixStep()" to="/step-4"><span>رأس المال الثابت</span>
                </router-link>
            </div>
            <div class="step-item done">
                <i></i>
                <router-link v-on:click.native="createSixStep()" to="/step-5"><span> تكاليف التشغيل </span>
                </router-link>
            </div>
            <div class="step-item active">
                <i></i>
                <router-link v-on:click.native="createSixStep()" to="/step-6"><span> الاستثمار والتمويل  </span>
            </router-link>
            </div>

            <div class="step-item">
                <i></i>
                <router-link v-on:click.native="createSixStep()" to="/step-7"><span> التقرير   </span>
            </router-link>
            </div>


        </div>
        <!-- // Steps -->
        <form @submit.prevent="createSixStep()" class="form-ui">

            <div class="row cols-gutter-20">
                <!-- Form Area -->
                <div class="col-s-12 col-m-8 col-l-9 clear-after">
                    <div class="content-box">
                        <h2 class="head">الاستثمار والتمويل</h2>

                        <div class="row clone-item">
                            <div class="col-s-12 col-m-4 title">التكلفه الاستثماريه الثابته</div>
                            <div class="col-s-12 col-m-8 title">القيمة</div>
                        </div>

                        <div class="row">
                            <div class="col-s-12 col-m-4"><span class="input-tit"> تكاليف الارض </span></div>
                            <div class="col-s-12 col-m-8">{{ this.asset1 }}</div>
                            <div class="col-s-12 col-m-4"><span class="input-tit"> تكاليف المباني والانشاءات </span></div>
                            <div class="col-s-12 col-m-8">{{ this.asset2 }}</div>
                            <div class="col-s-12 col-m-4"><span class="input-tit"> تكاليف الالات والمعدات </span></div>
                            <div class="col-s-12 col-m-8">{{ this.asset3 }}</div>
                            <div class="col-s-12 col-m-4"><span class="input-tit"> تكاليف السيارات </span></div>
                            <div class="col-s-12 col-m-8">{{ this.asset4 }}</div>
                            <div class="col-s-12 col-m-4"><span class="input-tit"> مصروفات التأسيس </span></div>
                            <div class="col-s-12 col-m-8">{{ this.asset5 }}</div>
                        </div>
                    </div>
                </div>
                <!-- // Form Area -->

                <!-- Description Area -->
                <div class="col-s-12 col-m-4 col-l-3 clear-after">
                    <div class="describe-box">
                        <p>
                            هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.</p>
                        <a href="#" class="more" target="_blank">قراء المزيد</a>
                    </div>
                </div>
                <!-- // Description Area -->
                <!-- Form Area -->
                <div class="col-s-12 col-m-8 col-l-9 clear-after">
                    <div class="content-box">
                        <h2 class="head">رأس المال العامل</h2>

                        <div class="row clone-item">
                            <div class="col-s-12 title">مدة رأس المال العامل</div>
                            <div class="col-s-12">
                                <select v-model="months" @change="workingCapital"  dir="rtl" class="">
                                    <option value="1">شهر</option>
                                    <option value="2">شهرين</option>
                                    <option value="3">3 اشهر</option>
                                    <option value="4">4 اشهر</option>
                                    <option value="5">5 اشهر</option>
                                    <option value="6">6 اشهر</option>
                                </select>
                            </div>
                        </div>
                        <div class="row clone-item">
                            <div class="col-s-12 col-m-4 title">رأس المال العامل</div>
                            <div class="col-s-12 col-m-4 title">القيمة / ريال</div>
                            <div class="col-s-12 col-m-4 title">رأس المال العامل</div>
                        </div>

                        <div v-for="capital in working_capital" class="row">
                                <div class="col-s-12 col-m-4"><span class="input-tit">{{capital.title}}</span>
                                </div>
                                <div class="col-s-12 col-m-4">{{capital.cost}}</div>
                                <div class="col-s-12 col-m-4">{{(capital.cost*2)/months}}</div>
                                <input v-model="total_capital" type="hidden" :value="(capital.cost*months)/12"/>
                        </div>
                    </div>
                </div>
                <!-- // Form Area -->
                <!-- Description Area -->
                <div class="col-s-12 col-m-4 col-l-3 clear-after">
                    <div class="describe-box">
                        <p>
                            هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.</p>
                        <a href="#" class="more" target="_blank">قراء المزيد</a>
                    </div>
                </div>
                <!-- // Description Area -->

                <!-- Form Area -->
                <div class="col-s-12 col-m-8 col-l-9 clear-after">
                    <div class="content-box">
                        <h2 class="head">اجمالي الاستثمار</h2>
                        <div class="row clone-item">
                            <div class="col-s-12 col-m-4 title">رأس المال المستثمر</div>
                            <div class="col-s-12 col-m-8 title">القيمة</div>
                        </div>
                        <div class="row">
                            <div class="col-s-12 col-m-4"><span class="input-tit"> رأس المال الثابت </span></div>

                            <div class="col-s-12 col-m-8"><div placeholder="القيمة">{{ this.total_cost }} </div></div>
                            <div class="col-s-12 col-m-4"><span class="input-tit" > رأس المال العامل </span></div>
                            <div class="col-s-12 col-m-8"><div placeholder="القيمة">{{ this.total_capital }} </div></div>
                            <div class="col-s-12 col-m-4"><span class="input-tit"> رأس المال المستثمر </span></div>
                            <div class="col-s-12 col-m-8"><div placeholder="القيمة">{{ this.all_total }} </div></div>
                        </div>
                    </div>
                </div>
                <!-- // Form Area -->
                <!-- Description Area -->
                <div class="col-s-12 col-m-4 col-l-3 clear-after">
                    <div class="describe-box">
                        <p>
                            هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.</p>
                        <a href="#" class="more" target="_blank">قراء المزيد</a>
                    </div>
                </div>
                <!-- // Description Area -->
                <!-- Form Area -->
                <div class="col-s-12 col-m-8 col-l-9 clear-after">
                    <div class="content-box">
                        <h2 class="head">مصادر التمويل</h2>
                        <div class="row clone-item">
                            <div class="col-s-12 col-m-4 title">نوع التمويل</div>
                            <div class="col-s-12 col-m-8 title">النسبه</div>
                        </div>
                        <div class="row" v-for="financeInvestment in financeInvestments">
                            <div class="col-s-12 col-m-4"><span class="input-tit"> تمويل ذاتي </span></div>
                            <div class="col-s-12 col-m-8"><input v-model="financeInvestment.personal_investment" value="" type="text" placeholder="النسبه"></div>
                            <div class="col-s-12 col-m-4"><span class="input-tit"> القرض </span></div>
                            <div class="col-s-12 col-m-8"><input v-model="financeInvestment.loan" value="" type="text" placeholder="النسبه"></div>
                            <div class="col-s-12 col-m-4"><span class="input-tit"> اخري </span></div>
                            <div class="col-s-12 col-m-8"><input v-model="financeInvestment.other" value="" type="text" placeholder="النسبه"></div>
                        </div>
                    </div>
                </div>
                <!-- // Form Area -->

                <!-- Description Area -->
                <div class="col-s-12 col-m-4 col-l-3 clear-after">
                    <div class="describe-box">
                        <p>
                            هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.</p>
                        <a href="#" class="more" target="_blank">قراء المزيد</a>
                    </div>
                </div>
                <!-- // Description Area -->

                <!-- buttons -->
                <div class="col-s-12 col-m-8 col-l-9 clear-after">
                    <input type="hidden" id="studyId" value="" name="studyId" v-model="studyId"/>
                    <router-link v-on:click.native="createSixStep()" to="/step-5"
                                 class="btn round-corner right prev-btn">الخطوة السابقه
                    </router-link>
                    <button class="btn secondary round-corner left next-btn" type="submit">التقرير  </button>

                </div>
                <!-- // buttons -->


            </div>

        </form>

    </div>
</template>
<script>
    export default {
        data() {
            return {
                step: 'step-six',
                studyId:0,
                asset1:0,
                asset2:0,
                asset3:0,
                asset4:0,
                asset5:0,
                capital:0,
                working_capital: [],
                months: 1,
                total_cost: 0,
                total_capital: 0,
                studyId: 0,
                all_total: 0,
                financeInvestments: [{personal_investment:''}],

            }
        },
        created() {
            this.workingCapital();
            this.getTotal();
            this.fireEvent();

        },
        methods: {
            createSixStep(){
                this.$http.post(window.hostname +'/api/study-finance-investments/add',{financeInvestments:this.financeInvestments,sid:this.studyId}).then(function(respone){
                    console.log(respone);
                });


            },
            workingCapital() {
                this.$http.get(window.hostname + '/api/expense_categories/working-capital').then(function (response) {
                    this.working_capital = response.data.working_capital
                        let sum=0
                        let months=this.months
                        response.data.working_capital.map(function(value, key) {
                            sum+=(value.cost*2)/months
                        });
                       console.log(sum);
                       this.total_capital=sum;
                       this.all_total=this.total_cost+this.total_capital;
                });
            }
            ,fireEvent(){
                let list1=0
                let list2=0
                let list3=0
                let list4=0
                let list5=0
                this.$http.get(window.hostname + '/ar/get-id').then(function (response) {
                    //this.info.user_id = response.data.user_id
                    this.$http.get(window.hostname + '/api/studies/study-by-user-id/' + response.data.user_id).then(function (response) {
                        this.studyId = response.data.study.id

                        this.$http.get(window.hostname + '/api/study-assets/' + this.studyId).then(function (response) {
                            if (response.data.assets) {


                                response.data.assets.map(function(value, key) {
                                    if(value.deprecation_id==1){
                                        list1+= value.value*value.space
                                    }
                                    if(value.deprecation_id==2){
                                        list2+= value.value*value.space
                                    }
                                    if(value.deprecation_id==3){
                                        list3+= value.value*value.count
                                    }
                                    if(value.deprecation_id==4){
                                        list4+= value.value*value.count
                                    }
                                    if(value.deprecation_id==5){
                                        list5+= value.value
                                    }

                                });

                                //console.log(response.sectors);
                                this.workingCapital()
                                this.asset1=list1
                                this.asset2=list2
                                this.asset3=list3
                                this.asset4=list4
                                this.asset5=list5
                                this.total_cost=list1+list2+list3+list4+list5;



                            }
                        });

                        this.$http.get(window.hostname + '/api/study-finance-investments/' + this.studyId).then(function (response) {
                            if(response.data.financeInvestments){
                                this.financeInvestments=response.data.financeInvestments
                            }

                        });

                    });

                });

            },
            getTotal() {
            }
        }
    }
</script>