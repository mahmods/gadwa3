<template>
    <div class="container page-content">
        <!-- Steps -->
        <div class="steps">
            <div class="step-item done">
                <i></i>
                <router-link v-on:click.native="createFifthStep()" :to="{ name: 'Stepone' }"><span></span>بيانات المشروع
                </router-link>
            </div>
            <div class="step-item done">
                <i></i>
                <router-link v-on:click.native="createFifthStep()" to="/step-2"><span>بيانات السوق</span></router-link>
            </div>
            <div class="step-item done">
                <i></i>
                <router-link v-on:click.native="createFifthStep()" to="/step-3"><span>الطاقه الانتاجيه</span>
                </router-link>
            </div>
            <div class="step-item done">
                <i></i>
                <router-link v-on:click.native="createFifthStep()" to="/step-4"><span>رأس المال الثابت</span>
                </router-link>
            </div>
            <div class="step-item active">
                <i></i>
                <router-link v-on:click.native="createFifthStep()" to="/step-5"><span> تكاليف التشغيل </span>
                </router-link>
            </div>
            <div class="step-item">
                <i></i>
                <router-link v-on:click.native="createFifthStep()" to="/step-6"><span> الاستثمار والتمويل  </span>
                </router-link>
            </div>
        </div>
        <!-- // Steps -->
        <form @submit.prevent="createFifthStep()" class="form-ui">
            <div class="row cols-gutter-20">

                <!-- Form Area -->
                <div class="col-s-12 col-m-8 col-l-9 clear-after">
                    <div class="content-box">
                        <h2 class="head">تكاليف التشغيل الكليه</h2>

                        <div class="form-ui">
                            <!-- Area Titles -->
                            <div class="clone-area">
                                <div class="row cols-gutter-10 clone-item">
                                    <div class="col-s-12 col-m-6 col-l-3 title">نوع المنتج</div>
                                    <div class="col-s-12 col-m-6 col-l-3 title">وحدة القياس</div>
                                    <div class="col-s-12 col-m-6 col-l-3 title">الطاقه التشغيليه الشهريه</div>
                                    <div class="col-s-12 col-m-6 col-l-3 title">تكلفه الوحدة</div>
                                </div>
                            </div>
                            <!-- // Area Titles -->
                            <div class="clone-area">
                                <!-- clone item -->
                                <div class="clone-item">
                                    <div class="row" v-for="(row_material,index) in row_materials">
                                        <div class="col-s-12 col-m-6 col-l-3">
                                            <input v-model="row_material.title" name="row_material[]" type="text"
                                                   placeholder="اسم المنتج">
                                        </div>
                                        <div class="col-s-12 col-m-6 col-l-3">
                                            <select v-model="row_material.unit_id" name="row_materials[]" dir="rtl"
                                                    class="">
                                                <option v-for="unit in unites" :value="unit.id">{{unit.title}}
                                                </option>
                                            </select>
                                        </div>
                                        <div class="col-s-12 col-m-6 col-l-3">
                                            <input v-model="row_material.production" name="row_materials[]" type="text"
                                                   placeholder="الطاقه الانتاجيه">
                                        </div>
                                        <div class="col-s-12 col-m-6 col-l-3">
                                            <input v-model="row_material.price" name="row_materials[]" type="text"
                                                   placeholder="السعر">
                                        </div>
                                        <!--<input type="hidden" id="productId" value="" name="productId" v-model="product.id"/>-->
                                        <button type="button" @click="removeRowMaterial" :data-index="index"
                                                class="remove-button ti-trash-b-io">
                                        </button>
                                    </div>
                                    <button type="button" @click="addRowMaterial" class="add-button ti-plus-io">
                                    </button>
                                </div>
                                <!-- // clone item -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- // Form Area -->
                <div class="col-s-12 col-m-4 col-l-3 clear-after">
                    <div class="describe-box">
                        <p>هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق.</p>
                        <a href="#" class="more" target="_blank">قراء المزيد</a>
                    </div>
                </div>
                <!-- Form Area -->
                <div v-for="category in expense_categories" class="col-s-12 col-m-8 col-l-9 clear-after">
                    <div class="content-box">
                        <h2 class="head">{{category.title}}</h2>
                        <div class="form-ui">
                            <div class="clone-area">
                                <!-- clone item -->
                                <div class="clone-item">
                                    <div v-if="expense.category_id ==category.id" v-for="(expense,index) in expenses" class="row">
                                        <div  v-show="(category.id==1 || category.id==5)" v-bind:class="[category.id==1 ? 'col-s-12 col-m-6' : 'col-s-12 col-m-4']">
                                            <input v-model="expense.item" name="expenses[]" type="text" placeholder="بيان">
                                        </div>
                                        <div v-show=" category.id==5" v-bind:class="{ 'col-s-12 col-m-4': category.id==5 }">
                                            <input v-model="expense.count" name="expenses[]" type="text" placeholder="العدد">
                                        </div>
                                        <div v-show="(category.id==2 || category.id==3)" v-bind:class="{ 'col-s-12 col-m-6': (category.id==2 || category.id==3) }" >
                                            <input v-model="expense.type" name="expenses[]" type="text" placeholder="النوع">
                                        </div>
                                        <div v-show="category.id==4" v-bind:class="{ 'col-s-12 col-m-4': category.id==4 }">
                                            <input v-model="expense.location" name="expenses[]" type="text" placeholder="الموقع">
                                        </div>
                                        <div v-show="category.id==4" v-bind:class="{ 'col-s-12 col-m-4': category.id==4 }">
                                            <input v-model="expense.space" name="expenses[]" type="text" placeholder="المساحة">
                                        </div>
                                        <div v-bind:class="[category.id==4 || category.id==5? 'col-s-12 col-m-4' : 'col-s-12 col-m-6']" >
                                            <input v-model="expense.value" name="expenses[]" type="text" placeholder="التكلفه الشهريه">
                                        </div>
                                        <button type="button" @click="removeExpense" :data-index="index"
                                                class="remove-button ti-trash-b-io">
                                        </button>
                                    </div>
                                    <button type="button" @click="addExpense(category.id)" class="add-button ti-plus-io">
                                    </button>
                                </div>
                                <!-- // clone item -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- // Form Area -->

                <!-- buttons -->
                <div class="col-s-12 col-m-8 col-l-9 clear-after">
                    <router-link v-on:click.native="createFifthStep()" to="/step-4" class="btn round-corner right prev-btn">الخطوة السابقه</router-link>
                    <button class="btn secondary round-corner left next-btn" type="submit">الخطوة التالية</button>
                </div>
                <!-- // buttons -->
            </div>
        </form>
    </div>
</template>
<script>
    export default {
        data() {
            return {
                row_materials: [
                    {
                        title: '',
                        unit_id: '',
                        production: '',
                        price: '',
                    }
                ],
                expense_categories: [],
                expenses: [
                    {
                        category_id: 1,
                        type: '',
                        item: '',
                        location: '',
                        space: null,
                        count: null,
                        value: null,
                    },
                    {
                        category_id: 2,
                        type: '',
                        item: '',
                        location: '',
                        space: null,
                        count: null,
                        value: null,
                    },
                    {
                        category_id: 3,
                        type: '',
                        item: '',
                        location: '',
                        space: null,
                        count: null,
                        value: null,
                    },
                    {
                        category_id: 4,
                        type: '',
                        item: '',
                        location: '',
                        space: null,
                        count: null,
                        value: null,
                    },
                    {
                        category_id: 5,
                        type: '',
                        item: '',
                        location: '',
                        space: null,
                        count: null,
                        value: null,
                    },

                ],
                studyId: 0,
                unites: [],
            }
        },
        created() {
            this.getUnites();
            this.getExpenseCategories();
            this.fireEvent();
        },
        methods: {
            getUnites() {
                this.$http.get(window.hostname + '/api/unites').then(function (response) {
                    this.unites = response.data
                });
            },
            getExpenseCategories() {
                this.$http.get(window.hostname + '/api/expense_categories').then(function (response) {
                    this.expense_categories = response.data
                });
            },
            createFifthStep() {
                this.$http.post(window.hostname + '/api/study-raw-materials/add-raw-material', {
                    row_materials: this.row_materials,
                    sid: this.studyId
                }).then(function (respone) {
                    console.log(respone);
                });
                this.$http.post(window.hostname + '/api/expenses/add-expense', {
                    expenses: this.expenses,
                    sid: this.studyId
                }).then(function (respone) {
                    console.log(respone);
                });
                //this.$router.push('/step-6');

            },
            addRowMaterial: function () {
                this.row_materials.push(
                    {
                        title: '',
                        unit_id: '',
                        production: '',
                        price: '',
                    }
                );
            },
            removeRowMaterial(e){
                var index = e.target.getAttribute('data-index');
                this.row_materials.splice(index, 1);
            },
            addExpense: function (id) {
                    this.expenses.push(
                        {
                            category_id: id,
                            type: '',
                            item: '',
                            location: '',
                            space: null,
                            count: null,
                            value: null,
                        }
                    );
            },
            removeExpense(e){
                var index = e.target.getAttribute('data-index');
                this.expenses.splice(index, 1);
            },
            fireEvent(){
                this.$http.get(window.hostname + '/ar/get-id').then(function (response) {
                    //this.info.user_id = response.data.user_id
                    this.$http.get(window.hostname + '/api/studies/study-by-user-id/' + response.data.user_id).then(function (response) {
                        this.studyId = response.data.study.id

                        this.$http.get(window.hostname + '/api/study-raw-materials/' + this.studyId).then(function (response) {
                            if (response.data.row_materials) {
                                this.row_materials = response.data.row_materials
                            }
                        });
                        this.$http.get(window.hostname + '/api/expenses/' + this.studyId).then(function (response) {
                            if (response.data.expenses)
                            {
                                this.expenses = response.data.expenses
                            }
                        })
                    });
                });
            }
        },
    }
</script>